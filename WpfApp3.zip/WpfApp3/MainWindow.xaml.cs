﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApp3
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void sliRGB_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            SzinesMiujsag();
        }

        public void SzinesMiujsag()
        {
            byte red, green, blue;
            red = Convert.ToByte(sliPiros.Value);
            green = Convert.ToByte(sliZold.Value);
            blue = Convert.ToByte(sliKek.Value);

            rctTeglalap.Fill = new SolidColorBrush(Color.FromRgb(red, green, blue));

            

            lbR1.Content = red;
            lbB1.Content = green;
            lbG1.Content = blue;

        }

        private void btnRogzit_Click(object sender, RoutedEventArgs e)
        {
            
            lbSzinek.Items.Add(($"{Convert.ToByte(sliPiros.Value)};{Convert.ToByte(sliZold.Value)};{Convert.ToByte(sliKek.Value)}"));
            string x = ($"{lbSzinek.Items.Add(lbR1.Content)};{lbG1.Content};{lbB1.Content}");
            {
                MessageBox.Show("nem jo xd");
            }
        }

        private void btnTorol_Click(object sender, RoutedEventArgs e)
        {
            if (lbSzinek.SelectedIndex ==-1)
            {
                MessageBox.Show("Szevasz");
            }
            else
            {
            lbSzinek.Items.RemoveAt(lbSzinek.SelectedIndex);

            }

        }

        private void btnUrit_Click(object sender, RoutedEventArgs e)
        {
            lbSzinek.Items.Clear();
            
        }

        private void lbSzinek_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            string[] RGBreszek = lbSzinek.SelectedItem.ToString().Split(';');

            byte red = Convert.ToByte(RGBreszek[0]);
            byte green = Convert.ToByte(RGBreszek[1]);
            byte blue = Convert.ToByte(RGBreszek[2]);

            //rctTeglalap.Fill = new SolidColorBrush(Color.FromRgb(red, green, blue));

            sliPiros.Value = red;
            sliZold.Value = green;
            sliKek.Value = blue;
        }

        private void lbSzinek_MouseDown(object sender, MouseButtonEventArgs e)
        {
            

        }
    }
}
